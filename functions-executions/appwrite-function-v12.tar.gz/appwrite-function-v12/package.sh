#!/bin/sh
cd ..
tar -zcvf appwrite-function-v12.tar.gz appwrite-function-v12
cd appwrite-function-v12